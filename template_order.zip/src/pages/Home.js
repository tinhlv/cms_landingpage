import React from 'react';

const Home = () => <div className="home"></div>;

export default Home;
